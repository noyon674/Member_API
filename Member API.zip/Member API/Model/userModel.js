//import files
const Mongoose = require('mongoose');

//create user schema like table
const userShema = Mongoose.Schema({
    ID: {
        type: String,
        require: true
    },
    Name: {
        type: String,
        require: true
    },
    Age: {
        type: Number,
        require: true
    },
    Address: {
        type: String,
        require: true
    },
    createdOn: {
        type: Date,
        default: Date.now
    },
});

//export file
module.exports = Mongoose.model('Member', userShema);