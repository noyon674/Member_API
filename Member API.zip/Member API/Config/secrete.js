//import files
require('dotenv').config();

const DEV = {
    port:{
        port: 1200 || process.env.PORT
    },
    db_link: {
        URL: process.env.DB_LINK
    }
};

//export file
module.exports = DEV;