//import files
const config = require('../Config/secrete');
const Mongoose = require('mongoose');

//database link
const DBLINK = config.db_link.URL;

//databse connection
Mongoose.connect(DBLINK)
.then(()=>{
    console.log('DataBase is connected.');
})
.catch((err)=>{
    console.log(err.message);
    process.exit(1);
});