//import file
const { v4 : uuidv4 } = require('uuid');
const Members = require('../Model/userModel');

//////all functions
//create member
const createMember = async(req, res)=>{
    try {
        const newUser = new Members({
            ID: uuidv4(),
            Name: req.body.Name,
            Age: req.body.Age,
            Address: req.body.Address

        });
        await newUser.save();
        res.status(201).json(newUser);

    } catch (error) {
        res.status(400).json(error.message);
    }
}

//get one member
const getOneMember = async(req, res)=>{
    try {
        const user = await Members.findOne({ID: req.params.id});
        res.status(200).json(user);
    } catch (error) {
        res.status(400).json(error.message);
    }
}

//get all member
const getAllMember = async (req, res)=>{
    try {
        const members = await Members.find();
        res.status(200).json(members);
    } catch (error) {
        res.status(400).json(error.message);
    }
}

//update member info
const updateMember = async (req, res)=>{
    try {
        const pickMember = await Members.findOne({ID: req.params.id});
        pickMember.Name = req.body.Name;
        pickMember.Age = req.body.Age;
        pickMember.Address = req.body.Address;

        await pickMember.save();
        res.status(200).json({
            Message: 'Member Info is updated'
        });
    } catch (error) {
        res.status(400).json(error.message);
    }
}

//delete member
const deleteMember = async (req, res)=>{
    try {
        await Members.deleteOne({ID: req.params.id});
        res.status(200).json({
            Message: 'Member is deleted'
        });
    } catch (error) {
        res.status(400).json(error.message);
    }
}

module.exports = {createMember, getOneMember, getAllMember, updateMember, deleteMember};