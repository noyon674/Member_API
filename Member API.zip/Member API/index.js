//import files
const App = require('./app');
const config = require('./Config/secrete');

const port = config.port.port;

//server run
App.listen(port, ()=>{
    console.log(`Server running at http://localhost:${port}`);
});
