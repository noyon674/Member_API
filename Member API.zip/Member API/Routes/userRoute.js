//import files
const Router = require('express').Router();
const {createMember, getOneMember, getAllMember, updateMember, deleteMember} = require('../Controller/userController');

//all routes
Router.post('/createMember', createMember); //create member route

Router.get('/getOneMember/:id', getOneMember); //get one member route

Router.get('/getAllMember', getAllMember); //get all member route

Router.patch('/updateMember/:id', updateMember); //update member route

Router.delete('/deleteMember/:id', deleteMember); //delete member route

//export file
module.exports = Router;